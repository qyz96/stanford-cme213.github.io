#ifndef _MATRIX_HPP
#define _MATRIX_HPP

class Matrix
{
};

class MatrixSymmetric
{
};

#endif /* MATRIX_HPP */