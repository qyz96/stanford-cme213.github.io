#include <cstdio>
#include <cstdlib>
#include <cassert>
#include "mpi.h"
#include "jacobi.h"

void Setup_mesh(int maxm, int maxn, Mesh *mesh)
{
    int rank, size;

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    mesh->down_nbr = (rank > 0 ? rank - 1 : -1);
    mesh->up_nbr = (rank < size - 1 ? rank + 1 : -1);

    /* Number of local rows */
    int lrow = (maxn - 2) / size;
    printf("rank %d row %5d to %5d\n", rank, 1 + rank * lrow, (1 + rank) * lrow);

    assert(((maxn - 2) % size) == 0);

    //  if (rank < ((maxn - 2) % size))
    // lrow++;

    mesh->lrow = lrow;
    mesh->maxm = maxm;
    mesh->maxn = maxn;

    /* Allocate the local meshes */
    mesh->xlocal = (double *)malloc(maxm * (lrow + 2) * sizeof(double));
    mesh->xnew = (double *)malloc(maxm * (lrow + 2) * sizeof(double));

    if (!mesh->xlocal || !mesh->xnew)
    {
        printf("Unable to allocate local mesh\n");
        MPI_Abort(MPI_COMM_WORLD, 1);
    }
}

void Init_mesh(Mesh *mesh)
{
    int i, j, lrow, rank, maxm;
    double *xlocal, *xnew;

    xlocal = mesh->xlocal;
    xnew = mesh->xnew;
    lrow = mesh->lrow;
    maxm = mesh->maxm;

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);

    const int global_row = rank * lrow * maxm;

    /* Fill the data as specified */
    for (i = 1; i <= lrow; i++)
        for (j = 0; j < maxm; j++)
        {
            xlocal[i * maxm + j] = global_row + i * maxm + j * j;
            xnew[i * maxm + j] = xlocal[i * maxm + j];
        }

    /* Boundary data or initial values in ghost cells */
    for (j = 0; j < maxm; j++)
    {
        xlocal[j] = global_row + j * j;
        xlocal[(lrow + 1) * maxm + j] = global_row + (lrow + 1) * maxm + j * j;
        xnew[j] = xlocal[j];
        xnew[(lrow + 1) * maxm + j] = xlocal[(lrow + 1) * maxm + j];
    }

    /* Boundary data in xnew if we use the "swap" approach */
    for (i = 0; i <= lrow + 1; i++)
    {
        xnew[i * maxm] = global_row + i * maxm;
        xnew[i * maxm + maxm - 1] = global_row + i * maxm + (maxm - 1) * (maxm - 1);
    }
}