#ifndef JACOBI_H
#define JACOBI_H

#include "mpi.h"

struct Mesh
{
    double *xlocal;
    double *xnew;
    int lrow;
    int maxn, maxm;
    int up_nbr, down_nbr;
};

#endif