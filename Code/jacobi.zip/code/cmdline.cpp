#include <cstdio>
#include <cstdlib>
#include <cstring>
#include "jacobi.h"

/* 
 * maxm: number of columns
 * maxn: number of rows in the global mesh. 
 * Because the mesh is divided into row-oriented slabs, the
 * resulting pieces are roughly maxm x maxn/p. 
 * See setupmesh.cpp for the exact dimensions.
 */

#define DEFAULT_MAXN 1024

void Get_command_line(int rank, int argc, char **argv, int *maxm, int *maxn, int *do_print, int *maxit)
{
    *maxn = DEFAULT_MAXN;
    *maxm = -1;

    for (int i = 1; i < argc; i++)
    {
        if (!argv[i])
            continue;
        if (strcmp(argv[i], "-print") == 0)
            *do_print = 1;
        else if (strcmp(argv[i], "-n") == 0)
        {
            *maxn = atoi(argv[i + 1]);
            i++;
        }
        else if (strcmp(argv[i], "-m") == 0)
        {
            *maxm = atoi(argv[i + 1]);
            i++;
        }
        else if (strcmp(argv[i], "-maxit") == 0)
        {
            *maxit = atoi(argv[i + 1]);
            i++;
        }
    }

    if (*maxm < 0)
        *maxm = *maxn;
}