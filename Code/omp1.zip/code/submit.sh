#!/bin/bash

#PBS -N cme213 
#PBS -q gpu
#PBS -j oe
#PBS -o cme213.out 
#PBS -l nodes=1

PBS_O_WORKDIR='/home/darve/CME213/Lecture_04/code'
export PBS_O_WORKDIR 

cd $PBS_O_WORKDIR
#./hello_world_openmp
#./shared_private_openmp
#./matrix_prod_openmp -n 1000 -p 24 -g &
#./matrix_prod_openmp -n 4000 -p 24 &
# time ./section
./list

echo "--- Top ---"
top -b -n 1 -u darve
echo

job=`jobs -p`
wait $job
