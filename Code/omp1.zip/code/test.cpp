#include <cstdio>

int main()
{
#pragma omp parallel
  {
    printf("Hello CME 213\n");
  }
  return 0;
}
